# Better Battlelog Chrome Extension Code

This folder contains the complete source code for the chrome/opera extension.